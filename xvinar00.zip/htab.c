#include "htab.h"

extern inline bool htab_iterator_valid(htab_iterator_t it);

extern inline bool htab_iterator_equal(htab_iterator_t it1, htab_iterator_t it2);

